# while 사용하기 불편하다..
# 특정 횟수를 반복하려면.. 순수 while문 이외에.. 이 순환문을 
# 제어 할수 있는 변수가 따로 필요하다.
#  for 문---> 횟수로 제어할때

test_list = ['one','two','three']
for i in test_list:
    print(i)
    
    
for i in range(10):
    print(i)    


# while   제어용. 변수를 사용하지 않는다..
# 무한루프를 돌면서.. 순환문안에 break를 넣어서 표현
# 특정조건을 만족할때 까지  순환

# for문은 집합데이터와 함께
# while은 조건과 함게

    