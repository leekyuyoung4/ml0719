jumsu = int(input("시험성적을 입력하세요(0~100) : "))

# 점수가 60점 이상이면 Success  그렇지 않으면 Faile
# if jumsu >= 60:
#     print("Success.")

# if jumsu < 60:
#     print("Faile.")
    
    
if jumsu >=60:
    print("Success.")
else:
    print("false")
        